# Moyai-spammer
Hello! The app was designed to troll ur friend's dms with the 🗿 emoji without having to copy the emoji just to waste ur last copied text if u copied something important
# App features
It doesnt contain that much of features except for some buttons that embeds 🗿 emojis to ur chatbox within ur selected app (whatsapp,telegram,etc) more features to come soon
# Suggestions/bugs
If u want to suggest a feature to this app or found a bug to report dont hesitate to email me (hg13master@gmail.com) or use the github's issues section
# Privacy Policy
If u want to read the privacy policy of my app click the privacy policy file or go [here](https://github.com/hg13bs/Moyai-spammer/blob/main/Privacy-Policy)
